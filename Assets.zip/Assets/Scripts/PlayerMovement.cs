﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody rb;
    public Vector3 InputVector;
    public float speed;
    public Dictionary<Vector3, Block> blocks = new Dictionary<Vector3, Block>();
    public Color color;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    
    }

    // Update is called once per frame
    void Update()
    {
        InputVector = new Vector3(Input.GetAxis("Horizontal") * speed, rb.velocity.y, Input.GetAxis("Vertical") * speed);
    }
    void FixedUpdate()
    {
        rb.velocity = InputVector;
    }
    
}
