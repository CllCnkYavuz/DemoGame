﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    private int requiredBlocks;
    private Game game;
    void Start()
    {
        game = FindObjectOfType<Game>();
        requiredBlocks = GameObject.FindGameObjectsWithTag("Blue").Length;
    }

    public void CheckForCompletion(int blockCount)
    {
        if (blockCount >= requiredBlocks)
        {
            game.LoadNextLevel();
        }

    }
}
