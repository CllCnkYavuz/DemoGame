﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Saw : MonoBehaviour
{
    public Transform saw;
    public Vector3 rotation;
    int blocks=0;
    public Game game;
    public GameObject blockDestructionParticles;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        saw.Rotate(rotation, rotation.magnitude * Time.deltaTime);
    }
    private void OnTriggerEnter(Collider other)
    {
        switch (other.tag)
        {
            case "Blue":
                {
                    Instantiate(blockDestructionParticles, transform.position, Quaternion.identity);
                  
                    blocks++;
                    Destroy(other.gameObject);
                    other.GetComponent<Block>().CheckForCompletion(blocks);

                    break;
                }
            case "White":
                {
                    game.ReloadCurrentLevel();


                    break;
                }
        }
    }
}
